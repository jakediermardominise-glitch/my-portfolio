const form = document.getElementById("studentForm")
const studentlist = document.getElementById("studentList")
const message = document.getElementById("message")

form.addEventListener("submit", function(event){

    event.preventDefault();

    const number = document.getElementById("studentNumber").value

    const first = document.getElementById("firstName").value

    const last = document.getElementById("lastName").value

    const course = document.getElementById("course").value

    const row = document.createElement("tr")

    const numberCell = document.createElement("td")
    const firstCell = document.createElement("td")
    const lastCell = document.createElement("td")
    const courseCell = document.createElement("td")

    numberCell.textContent = number
    firstCell.textContent = first
    lastCell.textContent = last
    courseCell.textContent = course

    row.appendChild(numberCell)
    row.appendChild(firstCell)
    row.appendChild(lastCell)
    row.appendChild(courseCell)

    studentList.appendChild(row)

    message.textContent = "Student added successfully"

    form.reset()

})

$(document).ready(function(){
    
    $("#dark").click(function(){
        $("body").addClass("dark-mode")
    })

    $("#light").click(function(){
        $("body").removeClass("dark-mode")
    })
})