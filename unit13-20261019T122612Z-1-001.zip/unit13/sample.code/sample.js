const button1 = document.getElementById("loadBTN")
const state = document.getElementById("state")
const status1 = document.getElementById("status")
const result = document.getElementById("result")

button1.addEventListener("click", function(){
    let ajaxRequest = new XMLHttpRequest()

    state.innerHTML = "readyState: " + ajaxRequest.
    readyState

    ajaxRequest.onreadystatechange = function () {

        state.innerHTML = "readyStatus" + ajaxRequest.readyState

        if (ajaxRequest.readyState == 4 && ajaxRequest.status == 200 ){

            status1.innerHTML = "readyState: " + ajaxRequest.status + "-" + ajaxRequest.statusText
        }
    }

    ajaxRequest.open("GET", "https://jsonplaceholder.typicode.com/users/1",true)

    ajaxRequest.send()
})